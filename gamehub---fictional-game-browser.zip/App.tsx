import React, { useState, useEffect, useCallback } from 'react';
import type { Game } from './types';
import { fetchGames, generateImage } from './services/gameService';
import Header from './components/Header';
import Footer from './components/Footer';
import GameGrid from './components/GameGrid';
import GameDetails from './components/GameDetails';
import Spinner from './components/Spinner';

const App: React.FC = () => {
  const [games, setGames] = useState<Game[]>([]);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [loadingMessage, setLoadingMessage] = useState<string>("جاري ابتكار عوالم الألعاب...");
  const [error, setError] = useState<string | null>(null);

  const loadGames = useCallback(async () => {
    setIsLoading(true);
    setGames([]);
    setError(null);
    setLoadingMessage("جاري ابتكار عوالم الألعاب...");
    try {
      const fetchedGames = await fetchGames();
      if (fetchedGames.length === 0) {
        setError("لم نتمكن من تحميل الألعاب. قد تكون هناك مشكلة في الاتصال بالخادم. يرجى المحاولة مرة أخرى لاحقًا.");
        setIsLoading(false);
      } else {
        setGames(fetchedGames);
      }
    } catch (e) {
      setError("حدث خطأ غير متوقع أثناء تحميل الألعاب.");
      console.error(e);
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadGames();
  }, [loadGames]);

  useEffect(() => {
    // This effect runs once when text data for games is fetched.
    if (games.length > 0 && games.every(g => g.posterUrl === '')) {
      setIsLoading(false); // Show the grid with placeholders
      
      const updateGameWithImages = (gameId: string, newUrls: { posterUrl: string; bannerUrl: string }) => {
        setGames(prevGames =>
          prevGames.map(g => (g.id === gameId ? { ...g, ...newUrls } : g))
        );
      };
      
      games.forEach(game => {
        const posterPrompt = `ملصق لعبة فيديو درامي للعبة بعنوان '${game.title}'. النوع: ${game.genre}. النمط: ملحمي، سينمائي، فني.`;
        const bannerPrompt = `بانر سينمائي عريض للعبة فيديو بعنوان '${game.title}'. بدون نص على الصورة.`;

        Promise.all([
          generateImage(posterPrompt, '3:4'),
          generateImage(bannerPrompt, '16:9'),
        ]).then(([posterUrl, bannerUrl]) => {
            updateGameWithImages(game.id, { posterUrl, bannerUrl });
        });
      });
    }
  }, [games]);

  const handleSelectGame = (game: Game) => {
    setSelectedGame(game);
  };

  const handleBackToGrid = () => {
    setSelectedGame(null);
  };

  const renderContent = () => {
    if (isLoading && games.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center h-screen">
          <Spinner />
          <p className="mt-4 text-xl text-gray-300">{loadingMessage}</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-screen text-center">
          <p className="text-2xl text-red-400 mb-4">{error}</p>
          <button
            onClick={loadGames}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      );
    }

    if (selectedGame) {
      return <GameDetails game={selectedGame} onBack={handleBackToGrid} />;
    }

    return <GameGrid games={games} onSelectGame={handleSelectGame} />;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default App;
