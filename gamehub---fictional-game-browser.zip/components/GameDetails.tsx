import React, { useState } from 'react';
import type { Game } from '../types';
import CpuIcon from './icons/CpuIcon';
import GpuIcon from './icons/GpuIcon';
import RamIcon from './icons/RamIcon';
import StorageIcon from './icons/StorageIcon';
import WindowsIcon from './icons/WindowsIcon';
import DownloadIcon from './icons/DownloadIcon';

interface GameDetailsProps {
  game: Game;
  onBack: () => void;
}

type DownloadState = 'idle' | 'downloading' | 'completed';

const DownloadButton: React.FC = () => {
  const [downloadState, setDownloadState] = useState<DownloadState>('idle');

  const handleDownload = () => {
    setDownloadState('downloading');
    setTimeout(() => {
      setDownloadState('completed');
    }, 3000);
  };

  const getButtonContent = () => {
    switch (downloadState) {
      case 'downloading':
        return (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            جاري التحميل...
          </>
        );
      case 'completed':
        return 'اكتمل التحميل!';
      case 'idle':
      default:
        return (
          <>
            <DownloadIcon />
            تحميل الآن
          </>
        );
    }
  };

  const buttonClasses = {
    idle: 'bg-blue-600 hover:bg-blue-700',
    downloading: 'bg-yellow-600 cursor-not-allowed',
    completed: 'bg-green-600 cursor-not-allowed',
  };

  return (
    <button
      onClick={handleDownload}
      disabled={downloadState !== 'idle'}
      className={`mt-8 w-full flex items-center justify-center text-xl font-bold py-4 px-6 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 ${buttonClasses[downloadState]}`}
    >
      {getButtonContent()}
    </button>
  );
};


const GameDetails: React.FC<GameDetailsProps> = ({ game, onBack }) => {
  return (
    <div className="animate-fade-in">
      <button
        onClick={onBack}
        className="mb-8 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
      >
        &larr; العودة إلى القائمة
      </button>

      <div className="relative w-full h-64 md:h-96 rounded-lg overflow-hidden shadow-2xl mb-8 bg-gray-800">
        {!game.bannerUrl ? (
            <div className="w-full h-full bg-gray-700 animate-shimmer bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700 bg-[length:200%_100%]"></div>
        ) : (
            <img src={game.bannerUrl} alt={`${game.title} banner`} className="w-full h-full object-cover animate-fade-in" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-8">
            <h2 className="text-5xl font-extrabold text-white shadow-md">{game.title}</h2>
            <p className="text-blue-300 text-lg">{game.genre}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-gray-800/50 p-6 rounded-lg">
          <h3 className="text-3xl font-bold mb-4 border-b-2 border-blue-500 pb-2">عن اللعبة</h3>
          <p className="text-gray-300 leading-relaxed text-lg">{game.description}</p>
           <div className="mt-6 text-gray-400">
                <p><strong>المطور:</strong> {game.developer}</p>
                <p><strong>سنة الإصدار:</strong> {game.releaseYear}</p>
            </div>
        </div>
        
        <div className="bg-gray-800/50 p-6 rounded-lg">
            <h3 className="text-3xl font-bold mb-4 border-b-2 border-blue-500 pb-2">متطلبات النظام</h3>
            <ul className="space-y-4 text-gray-300">
                <li className="flex items-center"><WindowsIcon /><span className="mr-3">{game.systemRequirements.os}</span></li>
                <li className="flex items-center"><CpuIcon /><span className="mr-3">{game.systemRequirements.cpu}</span></li>
                <li className="flex items-center"><GpuIcon /><span className="mr-3">{game.systemRequirements.gpu}</span></li>
                <li className="flex items-center"><RamIcon /><span className="mr-3">{game.systemRequirements.ram}</span></li>
                <li className="flex items-center"><StorageIcon /><span className="mr-3">{game.systemRequirements.storage}</span></li>
            </ul>
           <DownloadButton />
        </div>
      </div>
    </div>
  );
};

export default GameDetails;