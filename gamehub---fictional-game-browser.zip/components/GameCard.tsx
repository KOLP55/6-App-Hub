import React from 'react';
import type { Game } from '../types';

interface GameCardProps {
  game: Game;
  onSelectGame: (game: Game) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, onSelectGame }) => {
  return (
    <div
      onClick={() => onSelectGame(game)}
      className="bg-gray-800 rounded-lg overflow-hidden shadow-lg cursor-pointer transform hover:-translate-y-2 transition-transform duration-300 group"
      aria-label={`Select game: ${game.title}`}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onSelectGame(game)}
    >
      <div className="relative w-full h-80 bg-gray-800">
        {!game.posterUrl ? (
          <div className="w-full h-80 bg-gray-700 animate-shimmer bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700 bg-[length:200%_100%]"></div>
        ) : (
          <img 
            src={game.posterUrl} 
            alt={`${game.title} poster`} 
            className="w-full h-80 object-cover animate-fade-in"
          />
        )}
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold mb-2 truncate group-hover:text-blue-400 transition-colors">{game.title}</h3>
        <p className="text-sm text-gray-400 bg-gray-700 inline-block px-2 py-1 rounded">{game.genre}</p>
      </div>
    </div>
  );
};

export default GameCard;
