
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-400 mt-12">
      <div className="container mx-auto px-4 py-6 text-center">
        <p>&copy; {new Date().getFullYear()} GameHub. جميع الحقوق محفوظة.</p>
        <p className="text-sm mt-1">تم الإنشاء بواسطة مهندس React خبير و Gemini API.</p>
      </div>
    </footer>
  );
};

export default Footer;
