
import React from 'react';

const CpuIcon: React.FC = () => (
    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M12 6V3m0 18v-3m6-6h3m-3 6h3M9 6h6M9 9h6m-6 3h6m-6 3h6M9 12h6"></path>
        <rect x="7" y="7" width="10" height="10" rx="1" strokeWidth="2" stroke="currentColor" fill="none"></rect>
    </svg>
);

export default CpuIcon;
