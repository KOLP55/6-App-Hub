
import React from 'react';

const GpuIcon: React.FC = () => (
    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15H4a2 2 0 01-2-2V7a2 2 0 012-2h16a2 2 0 012 2v6a2 2 0 01-2 2h-1M13 15v-4h4v4h-4zM7 15v-4h4v4H7z"></path>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l-1 4h16l-1-4"></path>
    </svg>
);

export default GpuIcon;
