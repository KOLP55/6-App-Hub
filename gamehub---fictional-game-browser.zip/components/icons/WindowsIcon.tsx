
import React from 'react';

const WindowsIcon: React.FC = () => (
    <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M3,3H11V11H3V3M13,3H21V11H13V3M3,13H11V21H3V13M13,13H21V21H13V13Z"></path>
    </svg>
);

export default WindowsIcon;
