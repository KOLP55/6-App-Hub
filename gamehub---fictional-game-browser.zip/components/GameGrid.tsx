
import React from 'react';
import type { Game } from '../types';
import GameCard from './GameCard';

interface GameGridProps {
  games: Game[];
  onSelectGame: (game: Game) => void;
}

const GameGrid: React.FC<GameGridProps> = ({ games, onSelectGame }) => {
  return (
    <div>
      <h2 className="text-4xl font-bold mb-8 text-center border-b-2 border-blue-500 pb-2 inline-block">أحدث الألعاب</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {games.map((game) => (
          <GameCard key={game.id} game={game} onSelectGame={onSelectGame} />
        ))}
      </div>
    </div>
  );
};

export default GameGrid;
