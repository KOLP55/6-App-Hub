
export interface SystemRequirements {
  os: string;
  cpu: string;
  gpu: string;
  ram: string;
  storage: string;
}

export interface Game {
  id: string;
  title: string;
  description: string;
  genre: string;
  developer: string;
  releaseYear: number;
  systemRequirements: SystemRequirements;
  posterUrl: string;
  bannerUrl: string;
}
