import { GoogleGenAI, Type } from "@google/genai";
import type { Game } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'اسم اللعبة باللغة العربية. يجب أن يكون جذاباً وفريداً.',
      },
      description: {
        type: Type.STRING,
        description: 'وصف مفصل ومغري للعبة في فقرة واحدة.',
      },
      genre: {
        type: Type.STRING,
        description: 'نوع اللعبة (مثل: أكشن, مغامرات, استراتيجية, خيال علمي)',
      },
      developer: {
        type: Type.STRING,
        description: 'اسم مطور اللعبة (اسم خيالي)',
      },
      releaseYear: {
        type: Type.INTEGER,
        description: 'سنة إصدار اللعبة',
      },
      systemRequirements: {
        type: Type.OBJECT,
        properties: {
          os: { type: Type.STRING, description: 'مثال: Windows 10/11 64-bit' },
          cpu: { type: Type.STRING, description: 'مثال: Intel Core i7-9700K or AMD Ryzen 7 3700X' },
          gpu: { type: Type.STRING, description: 'مثال: NVIDIA GeForce RTX 3070 or AMD Radeon RX 6800' },
          ram: { type: Type.STRING, description: 'مثال: 16 GB RAM' },
          storage: { type: Type.STRING, description: 'مثال: 150 GB available space' },
        },
        required: ['os', 'cpu', 'gpu', 'ram', 'storage']
      },
    },
    required: ['title', 'description', 'genre', 'developer', 'releaseYear', 'systemRequirements']
  },
};

export const fetchGames = async (): Promise<Game[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "قم بإنشاء قائمة من 12 لعبة فيديو خيالية ولكن واقعية. يجب أن تكون أسماء الألعاب باللغة العربية. لكل لعبة، قدم وصفًا جذابًا، ونوعًا، ومطورًا، وسنة إصدار، ومتطلبات نظام مفصلة.",
      config: {
        responseMimeType: 'application/json',
        responseSchema,
      },
    });

    const jsonText = response.text.trim();
    const generatedGames = JSON.parse(jsonText);
    
    // Add unique IDs and empty image URLs to be populated later
    return generatedGames.map((game: Omit<Game, 'id' | 'posterUrl' | 'bannerUrl'>, index: number) => ({
      ...game,
      id: `${game.title.replace(/\s+/g, '-')}-${index}`,
      posterUrl: '', // Will be generated on the client
      bannerUrl: '', // Will be generated on the client
    }));

  } catch (error) {
    console.error("Error fetching games from Gemini API:", error);
    // In case of an API error, re-throw to be handled by the component.
    throw new Error("Failed to fetch game data.");
  }
};


export const generateImage = async (prompt: string, aspectRatio: '3:4' | '16:9'): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: aspectRatio,
            },
        });

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;
    } catch (error) {
        console.error(`Error generating image for prompt "${prompt}":`, error);
        return ''; // Return empty string on failure to not break the UI
    }
};